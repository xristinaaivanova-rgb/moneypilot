/** Deterministic financial forecast; all amounts are integer cents. */
export const day = value => String(value).slice(0, 10);
export function validCents(n) { return Number.isSafeInteger(n) && Math.abs(n) <= 100_000_000_000; }
export function addDays(iso, amount) { const d = new Date(`${day(iso)}T12:00:00Z`); d.setUTCDate(d.getUTCDate()+amount); return d.toISOString().slice(0,10); }
export function addMonths(iso, amount) {
  const [y,m,d] = day(iso).split('-').map(Number); const first = new Date(Date.UTC(y, m-1+amount, 1,12));
  const last = new Date(Date.UTC(first.getUTCFullYear(), first.getUTCMonth()+1,0,12)).getUTCDate();
  return `${first.getUTCFullYear()}-${String(first.getUTCMonth()+1).padStart(2,'0')}-${String(Math.min(d,last)).padStart(2,'0')}`;
}
export function occurrences(item, start, end) {
  if(item.status === 'paid' || item.status === 'canceled') return [];
  let cursor = day(item.due_date), count=0; const out=[]; const frequency=item.frequency||'once';
  // A bound avoids pathological recurrence loops on malformed data.
  while(cursor <= end && count++ < 1500) {
    if(cursor >= start) out.push({...item, occurrence_date:cursor});
    if(frequency==='once') break;
    if(frequency==='weekly') cursor=addDays(cursor,7);
    else if(frequency==='biweekly') cursor=addDays(cursor,14);
    else if(frequency==='monthly') cursor=addMonths(cursor,1);
    else if(frequency==='yearly') cursor=addMonths(cursor,12);
    else break;
  }
  return out;
}
export function forecast({accounts=[],items=[],today,horizonDays=30,reserveCents=0,includeEstimatedIncome=true}) {
  if(!/^\d{4}-\d{2}-\d{2}$/.test(today)) throw Error('Invalid planning date');
  const end=addDays(today,horizonDays);
  const current=accounts.filter(a=>a.is_available!==false).reduce((s,a)=>s+a.balance_cents,0);
  const protectedCents=accounts.reduce((s,a)=>s+(a.protected_cents||0),0);
  const starting=current-protectedCents-reserveCents;
  const events=items.flatMap(x=>occurrences(x,today,end)).sort((a,b)=>a.occurrence_date.localeCompare(b.occurrence_date)||((a.kind==='income'?1:0)-(b.kind==='income'?1:0))||a.id-b.id);
  let projected=starting, conservative=starting, minProjected=starting,minConservative=starting;
  let shortage=0, earliestShortage=null;
  const timeline=[];
  for(const e of events){
    if(!validCents(e.amount_cents)) throw Error('Invalid monetary input');
    const delta=e.kind==='income'?e.amount_cents:-e.amount_cents;
    if(e.kind!=='income'||includeEstimatedIncome||e.certainty==='confirmed') projected+=delta;
    if(e.kind!=='income') conservative+=delta;
    minProjected=Math.min(minProjected,projected);
    minConservative=Math.min(minConservative,conservative);
    if(projected<0 && !earliestShortage){earliestShortage=e.occurrence_date;shortage=-projected;}
    timeline.push({id:e.id,name:e.name,kind:e.kind,date:e.occurrence_date,amount_cents:e.amount_cents,projected_cents:projected,certainty:e.certainty||'estimated'});
  }
  return {current_cents:current,protected_cents:protectedCents,reserve_cents:reserveCents,
    safe_now_cents:Math.max(0,minConservative),projected_safe_cents:Math.max(0,minProjected),
    predicted_shortage_cents:Math.max(0,-minProjected),first_shortage_date:earliestShortage,
    projected_end_cents:projected,timeline,through:end,
    note:'Safe Now excludes future income; Projected includes only the income assumptions selected.'};
}
