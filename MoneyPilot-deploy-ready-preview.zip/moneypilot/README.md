# MoneyPilot — working development foundation (v0.1)

**Status:** Functional local development MVP, **not production-ready**. Based on the supplied *MoneyPilot Ultimate Full-Stack SaaS Master Prompt V4.0*. This is **not** a finished implementation of its 40-section specification.

## Run locally

Requires **Node.js 22+**. No third-party packages required.

```bash
npm start
```

Then open **http://localhost:3080**. Run `npm test` to execute deterministic financial tests. Set `PORT` to change the port. Data is stored in `data/moneypilot.sqlite` by default. Override directory with `DATA_DIR`. Back this up before experimenting with important data; do not put sensitive real financial data in this prototype.

## What actually works

- Public homepage `/`, navigation, homepage pricing presentation, responsive design.
- Bulgarian, English and Dutch translations for main public UI and labels (some forms and development notices remain in English).
- Registration, login and logout with salted scrypt password hashing, httpOnly SameSite cookie sessions, per-user SQLite records, server-side authentication, user-scoped API access.
- Accounts and protected amounts: create, edit, delete.
- Income, bills, subscriptions, debts, budgets and savings contribution **schedules**: create/edit/delete, weekly/biweekly/monthly/yearly/once recurrence, planned/paid/canceled status.
- SQLite persistence across refresh and restart.
- Deterministic integer-cent cash-flow forecast for 7/30/60/90 days, with conservative Safe-to-Spend and projected Safe-to-Spend, upcoming timeline and predicted shortages.
- JSON data export, permanent account deletion.
- 14-day trial timestamps recorded on the server and shown in UI; no card is collected or charged.
- Nine unit tests, project JS syntax checks.

## Important limitations — not yet delivered

- **Subscriptions and trial:** Pricing display only; no Stripe checkout, renewal, card handling, trial-expiry permissions, paid plan gating, invoices or webhooks. Trial expiry is informational, not access-enforced.
- **No banking connectivity** or balance synchronization. Marking a bill paid excludes it from forecast but **does not deduct it automatically from the account**; the user must update balance independently.
- **No full financial ledger**, historical transaction reconciliation, multi-currency FX, account-specific liquidity, salary allocation, scenario editor, debt amortization, full calendar, email notifications or AI assistant.
- **No email verification, reset password, login rate limiting, MFA, comprehensive auditing, scheduled recurring materialization, backups, production deployment, security review, GDPR legal review, or accessibility certification.**
- The demo button shows an illustrative preview; it is not yet an interactive demo account.
- **Financial engine limitations:** all amounts assumed EUR, forecast uses UTC date rather than user's configured local date, recurrences based on due date and month-end clamping, and only planned schedule status (not individual recurring occurrences). Balance is not recomputed from transactions. The shortage flag uses the projected path and is a planning estimate, not a guarantee. For monthly recurring events anchored on the 31st, a February clamp cascades to the 28th for later months; fix using a stored anchor date before production.
- Localization incomplete (form labels and some system notices).
- Legal policy and support pages not yet implemented.

## Next engineering work (priority)

1. Introduce a ledger-first account model and per-occurrence payment state; guarantee safe-to-spend calculations cannot double count balances or events. Add account-specific projected liquidity and recurring original-day anchoring.
2. Add tests for account access isolation, authentication, request validation, session expiry, cross-account access, end-to-end flows, DST/month-end and near-overflow.
3. Replace development session/database setup with production-hardened auth, migrations, robust secrets and operational security.
4. Implement real 14-day feature entitlements and Stripe **test-mode** checkout/webhook lifecycle; explicitly select correct EU VAT/consumer policies.
5. Add full nine-step onboarding, dedicated calendar, forecast charts, what-if simulations and assistant using deterministic backend tools.
6. Production readiness: translate all text; accessibility audit; security assessment; backups/recovery; GDPR and legal review; deploy with HTTPS and durable storage.

## API (development)

- `POST /api/register`, `/api/login`, `/api/logout`
- `GET /api/me`, `/api/snapshot?days=30`, `/api/export`
- `POST /api/accounts`, `PUT|DELETE /api/accounts/:id`
- `POST /api/items`, `PUT|DELETE /api/items/:id`
- `POST /api/delete-account`

API amounts are **integer euro cents**. Financial engine is in `src/engine.js`; tests in `tests/engine.test.js`. Client in `public/`.

## Security note

This is a local-development codebase with no audited security perimeter. When hosting for actual customers, enforce HTTPS (`COOKIE_SECURE=1`), configure a hardened authentication provider, implement rate limits and CSRF strategy, add strict database migrations and operational controls, and obtain legal/security review before entering live financial information. No real card charges are implemented.
